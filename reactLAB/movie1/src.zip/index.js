import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';

const root = ReactDOM.createRoot(document.getElementById('potato'));
root.render( //렌더링할 대상도 하나의 대상을 가리켜야 한다.
    
    // <App />
    <App>

    </App>
);



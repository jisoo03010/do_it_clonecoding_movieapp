function App2() {
    return (
        <span>
            <h1>Hi App2 ~!</h1>
        </span>

    );
}

export default App2;